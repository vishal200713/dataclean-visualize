"""
DataClean & Visualize — backend API
------------------------------------
A small Flask service that receives a CSV/Excel upload, profiles it,
cleans it according to user-chosen options, and serves the cleaned
data back to the frontend for tables, charts and export.

Run with:
    pip install -r requirements.txt
    python app.py

The API listens on http://localhost:5000 by default. It is a single
process, in-memory store — fine for a demo / single user. For a real
deployment, swap STORE for a database or cache keyed by session.
"""

import io
import uuid

import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, send_file
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# dataset_id -> {"raw": DataFrame, "clean": DataFrame, "filename": str}
STORE = {}

MAX_PREVIEW_ROWS = 5000


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def get_dataset(ds_id):
    if not ds_id or ds_id not in STORE:
        return None
    return STORE[ds_id]


def iqr_bounds(series):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    return q1 - 1.5 * iqr, q3 + 1.5 * iqr


def df_summary(df: pd.DataFrame) -> dict:
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = [c for c in df.columns if c not in numeric_cols]

    missing = df.isna().sum()
    outliers_by_column = {}
    outliers_total = 0
    for col in numeric_cols:
        series = df[col].dropna()
        if len(series) < 4:
            continue
        lo, hi = iqr_bounds(series)
        count = int(((series < lo) | (series > hi)).sum())
        if count:
            outliers_by_column[col] = count
            outliers_total += count

    return {
        "rows": int(len(df)),
        "columns": int(df.shape[1]),
        "missing_total": int(missing.sum()),
        "missing_by_column": {k: int(v) for k, v in missing.items() if v > 0},
        "duplicates": int(df.duplicated().sum()),
        "outliers_total": outliers_total,
        "outliers_by_column": outliers_by_column,
        "numeric_columns": numeric_cols,
        "categorical_columns": categorical_cols,
        "dtypes": {k: str(v) for k, v in df.dtypes.items()},
    }


def to_records(df: pd.DataFrame, limit=None):
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = out[col].astype(str)
    out = out.astype(object).where(pd.notnull(out), None)
    if limit:
        out = out.head(limit)
    return out.to_dict(orient="records")


def build_insights(clean_df: pd.DataFrame, raw_df: pd.DataFrame):
    numeric_cols = clean_df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = [c for c in clean_df.columns if c not in numeric_cols]
    findings = []

    for col in numeric_cols[:8]:
        series = clean_df[col].dropna()
        if series.empty:
            continue
        findings.append(
            f"In '{col}', values range from {series.min():.2f} to {series.max():.2f}, "
            f"averaging {series.mean():.2f}."
        )

    for col in categorical_cols[:6]:
        counts = clean_df[col].value_counts()
        if len(counts):
            top = counts.index[0]
            findings.append(
                f"The most common value in '{col}' is \"{top}\", appearing "
                f"{int(counts.iloc[0])} times."
            )

    if len(numeric_cols) >= 2:
        corr = clean_df[numeric_cols].corr(numeric_only=True)
        pairs = []
        for i, a in enumerate(numeric_cols):
            for b in numeric_cols[i + 1:]:
                val = corr.loc[a, b]
                if pd.notna(val) and abs(val) >= 0.6:
                    pairs.append((a, b, val))
        pairs.sort(key=lambda p: -abs(p[2]))
        for a, b, val in pairs[:5]:
            direction = "positive" if val > 0 else "negative"
            findings.append(
                f"'{a}' and '{b}' show a strong {direction} correlation ({val:.2f})."
            )

    date_cols = [c for c in clean_df.columns if pd.api.types.is_datetime64_any_dtype(clean_df[c])]
    if date_cols and numeric_cols:
        dc, nc = date_cols[0], numeric_cols[0]
        trend_df = clean_df[[dc, nc]].dropna().sort_values(dc)
        if len(trend_df) >= 2:
            change = trend_df[nc].iloc[-1] - trend_df[nc].iloc[0]
            direction = "increased" if change > 0 else "decreased" if change < 0 else "stayed flat"
            findings.append(f"'{nc}' has {direction} over the period covered by '{dc}'.")

    rows_removed = len(raw_df) - len(clean_df)
    missing_before = int(raw_df.isna().sum().sum())
    missing_after = int(clean_df.isna().sum().sum())
    findings.append(
        f"Cleaning changed the dataset from {len(raw_df)} to {len(clean_df)} rows "
        f"({rows_removed} removed) and cut missing values from {missing_before} to {missing_after}."
    )

    dup_before = int(raw_df.duplicated().sum())
    if dup_before:
        findings.append(f"{dup_before} duplicate row(s) were found in the original data.")

    return findings


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/api/upload", methods=["POST"])
def upload():
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file was uploaded."}), 400

    filename = file.filename or "dataset.csv"
    raw_bytes = file.read()
    size_bytes = len(raw_bytes)
    buffer = io.BytesIO(raw_bytes)

    try:
        if filename.lower().endswith((".xlsx", ".xls")):
            df = pd.read_excel(buffer)
        else:
            buffer.seek(0)
            df = pd.read_csv(buffer)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": f"Could not parse '{filename}': {exc}"}), 400

    if df.empty:
        return jsonify({"error": "The uploaded file has no rows."}), 400

    # Best-effort date parsing so time-based insights/charts work.
    for col in df.columns:
        if df[col].dtype == object:
            sample = df[col].dropna().head(20)
            if len(sample) and sample.astype(str).str.match(
                r"^\d{4}-\d{2}-\d{2}"
            ).mean() > 0.7:
                try:
                    df[col] = pd.to_datetime(df[col], errors="coerce")
                except Exception:  # noqa: BLE001
                    pass

    ds_id = str(uuid.uuid4())
    STORE[ds_id] = {"raw": df, "clean": df.copy(), "filename": filename}

    return jsonify({
        "dataset_id": ds_id,
        "filename": filename,
        "size_bytes": size_bytes,
        "rows": len(df),
        "columns": df.shape[1],
        "column_names": df.columns.tolist(),
        "preview": to_records(df, limit=10),
        "summary": df_summary(df),
    })


@app.route("/api/clean", methods=["POST"])
def clean():
    body = request.get_json(force=True, silent=True) or {}
    ds = get_dataset(body.get("dataset_id"))
    if ds is None:
        return jsonify({"error": "Unknown dataset_id. Upload a file first."}), 404

    df = ds["raw"].copy()
    before_summary = df_summary(df)
    options = body.get("options", {})

    if options.get("remove_duplicates"):
        df = df.drop_duplicates()

    missing_opt = options.get("missing", {})
    strategy = missing_opt.get("strategy", "none")
    if strategy == "drop":
        df = df.dropna()
    elif strategy == "fill":
        method = missing_opt.get("method", "mean")
        custom_value = missing_opt.get("custom_value")
        for col in df.columns:
            if df[col].isna().sum() == 0:
                continue
            if method == "mean" and pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(df[col].mean())
            elif method == "median" and pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(df[col].median())
            elif method == "mode":
                mode_vals = df[col].mode()
                if len(mode_vals):
                    df[col] = df[col].fillna(mode_vals.iloc[0])
            elif method == "custom" and custom_value is not None:
                df[col] = df[col].fillna(custom_value)

    outlier_opt = options.get("outliers", {})
    outlier_method = outlier_opt.get("method", "none")
    if outlier_method in ("remove", "cap"):
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if outlier_method == "cap":
            for col in numeric_cols:
                lo, hi = iqr_bounds(df[col].dropna())
                df[col] = df[col].clip(lower=lo, upper=hi)
        else:  # remove
            mask = pd.Series(True, index=df.index)
            for col in numeric_cols:
                lo, hi = iqr_bounds(df[col].dropna())
                mask &= df[col].isna() | df[col].between(lo, hi)
            df = df[mask]

    normalize = options.get("normalize", "none")
    if normalize in ("minmax", "zscore"):
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if normalize == "minmax":
                lo, hi = df[col].min(), df[col].max()
                if hi > lo:
                    df[col] = (df[col] - lo) / (hi - lo)
            else:
                mu, sd = df[col].mean(), df[col].std()
                if sd and sd > 0:
                    df[col] = (df[col] - mu) / sd

    ds["clean"] = df

    return jsonify({
        "before": before_summary,
        "after": df_summary(df),
        "rows": len(df),
        "preview": to_records(df, limit=10),
    })


@app.route("/api/data", methods=["GET"])
def data():
    ds = get_dataset(request.args.get("dataset_id"))
    if ds is None:
        return jsonify({"error": "Unknown dataset_id."}), 404
    which = request.args.get("which", "clean")
    df = ds.get(which, ds["clean"])
    return jsonify({
        "columns": df.columns.tolist(),
        "numeric_columns": df.select_dtypes(include=[np.number]).columns.tolist(),
        "rows": to_records(df, limit=MAX_PREVIEW_ROWS),
        "total_rows": len(df),
    })


@app.route("/api/summary", methods=["GET"])
def summary():
    ds = get_dataset(request.args.get("dataset_id"))
    if ds is None:
        return jsonify({"error": "Unknown dataset_id."}), 404
    which = request.args.get("which", "clean")
    df = ds.get(which, ds["clean"])
    return jsonify(df_summary(df))


@app.route("/api/correlation", methods=["GET"])
def correlation():
    ds = get_dataset(request.args.get("dataset_id"))
    if ds is None:
        return jsonify({"error": "Unknown dataset_id."}), 404
    df = ds["clean"]
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < 2:
        return jsonify({"columns": numeric_cols, "matrix": []})
    corr = df[numeric_cols].corr(numeric_only=True).round(3)
    matrix = [[None if pd.isna(v) else v for v in row] for row in corr.values.tolist()]
    return jsonify({"columns": numeric_cols, "matrix": matrix})


@app.route("/api/insights", methods=["GET"])
def insights():
    ds = get_dataset(request.args.get("dataset_id"))
    if ds is None:
        return jsonify({"error": "Unknown dataset_id."}), 404
    return jsonify({"insights": build_insights(ds["clean"], ds["raw"])})


@app.route("/api/export", methods=["GET"])
def export():
    ds = get_dataset(request.args.get("dataset_id"))
    if ds is None:
        return jsonify({"error": "Unknown dataset_id."}), 404
    fmt = request.args.get("format", "csv")
    df = ds["clean"]
    base = (ds["filename"].rsplit(".", 1)[0] or "dataset")

    if fmt == "xlsx":
        buffer = io.BytesIO()
        with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Cleaned Data")
        buffer.seek(0)
        return send_file(
            buffer,
            as_attachment=True,
            download_name=f"{base}_cleaned.xlsx",
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    buffer = io.BytesIO()
    df.to_csv(buffer, index=False)
    buffer.seek(0)
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f"{base}_cleaned.csv",
        mimetype="text/csv",
    )


@app.route("/api/report", methods=["GET"])
def report():
    ds = get_dataset(request.args.get("dataset_id"))
    if ds is None:
        return jsonify({"error": "Unknown dataset_id."}), 404

    clean_df, raw_df = ds["clean"], ds["raw"]
    summary = df_summary(clean_df)
    finding_list = build_insights(clean_df, raw_df)

    lines = [
        "DataClean & Visualize — Summary Report",
        "=" * 42,
        f"Dataset: {ds['filename']}",
        "",
        "Summary",
        "-" * 42,
        f"Rows: {summary['rows']}",
        f"Columns: {summary['columns']}",
        f"Missing values remaining: {summary['missing_total']}",
        f"Duplicate rows remaining: {summary['duplicates']}",
        f"Outliers remaining: {summary['outliers_total']}",
        f"Numeric columns: {', '.join(summary['numeric_columns']) or 'none'}",
        f"Categorical columns: {', '.join(summary['categorical_columns']) or 'none'}",
        "",
        "Key Insights",
        "-" * 42,
    ]
    lines += [f"- {item}" for item in finding_list]
    content = "\n".join(lines)

    buffer = io.BytesIO(content.encode("utf-8"))
    return send_file(
        buffer,
        as_attachment=True,
        download_name="summary_report.txt",
        mimetype="text/plain",
    )


if __name__ == "__main__":
    app.run(debug=True, port=5000)
