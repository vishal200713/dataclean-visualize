# DataClean & Visualize

A data cleaning and visualization dashboard. Upload a CSV or Excel
file, clean it (missing values, duplicates, outliers, scaling),
explore it with interactive charts, read automatic insights, and
export the cleaned result.

- **Backend:** Python, Flask, Pandas, NumPy (`/backend`)
- **Frontend:** HTML, CSS, vanilla JavaScript, Plotly.js (`/frontend`)

## Project structure

```
dataclean-visualize/
├── backend/
│   ├── app.py            # Flask API (upload, clean, summary, insights, export)
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/script.js
└── README.md
```

## Running it locally

**1. Start the backend**

```bash
cd backend
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

The API runs at `http://localhost:5000`.

**2. Open the frontend**

The frontend is static — no build step. Either:

- open `frontend/index.html` directly in a browser, or
- serve it (recommended, avoids some browser file:// restrictions):

```bash
cd frontend
python -m http.server 8080
```

Then visit `http://localhost:8080`. If your backend runs somewhere
other than `http://localhost:5000`, set it before `script.js` loads:

```html
<script>window.API_BASE = "http://your-backend-host:5000";</script>
<script src="js/script.js"></script>
```

## Features

- **Upload** — drag-and-drop or browse for a `.csv` / `.xlsx` / `.xls`
  file; see file name, row/column counts and size, plus a 10-row
  preview.
- **Clean** — remove or fill missing values (mean, median, mode or a
  custom value), drop duplicate rows, cap or remove IQR-based
  outliers, and min-max or z-score normalize numeric columns. A
  before/after comparison shows the effect.
- **Summary** — stat cards for rows, columns, missing values,
  duplicates, outliers, and numeric/categorical column counts.
- **Visualize** — bar, line, pie/donut, histogram, scatter, box and
  correlation-heatmap charts with selectable X/Y columns, built with
  Plotly.js.
- **Insights** — automatic plain-language findings: min/max/average
  per numeric column, most frequent categories, strong correlations,
  trends over a date column, and the impact of cleaning.
- **Data table** — search, click-to-sort, pagination and column
  show/hide.
- **Export** — download the cleaned dataset as CSV or Excel, a text
  summary report, or the current chart as a PNG.

## Notes for production use

This project keeps uploaded data in an in-memory dictionary
(`STORE` in `backend/app.py`) keyed by a per-upload `dataset_id`,
which is fine for local use or a demo but is **not** multi-user or
persistence-safe. For production, replace `STORE` with a database or
cache (e.g. Redis) and add authentication before exposing the API
publicly.
