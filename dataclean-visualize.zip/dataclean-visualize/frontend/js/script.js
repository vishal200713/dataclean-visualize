// DataClean & Visualize — frontend logic
// Talks to the Flask backend defined in backend/app.py.

const API_BASE = window.API_BASE || "http://localhost:5000";

const state = {
  datasetId: null,
  filename: null,
  columns: [],
  numericColumns: [],
  tableRows: [],
  tableColumns: [],
  visibleColumns: new Set(),
  sortCol: null,
  sortDir: 1,
  page: 1,
  pageSize: 15,
  searchTerm: "",
};

// ---------------------------------------------------------------- nav
const navItems = document.querySelectorAll(".nav-item");
const pages = document.querySelectorAll(".page");

function goTo(section) {
  navItems.forEach(b => b.classList.toggle("active", b.dataset.section === section));
  pages.forEach(p => p.classList.toggle("active", p.id === `page-${section}`));
  document.getElementById("sidebar").classList.remove("open");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

navItems.forEach(btn => btn.addEventListener("click", () => goTo(btn.dataset.section)));
document.querySelectorAll("[data-goto]").forEach(el =>
  el.addEventListener("click", () => goTo(el.dataset.goto))
);

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("open");
});

// ---------------------------------------------------------------- helpers
function fmtBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

function setDatasetChip(text, loaded) {
  const chip = document.getElementById("datasetChip");
  chip.textContent = text;
  chip.classList.toggle("loaded", !!loaded);
}

async function apiFetch(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  let body;
  try { body = await res.json(); } catch { body = null; }
  if (!res.ok) {
    throw new Error((body && body.error) || `Request failed (${res.status})`);
  }
  return body;
}

// ---------------------------------------------------------------- upload
const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("fileInput");

["dragenter", "dragover"].forEach(evt =>
  dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.add("dragover"); })
);
["dragleave", "drop"].forEach(evt =>
  dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.remove("dragover"); })
);
dropzone.addEventListener("drop", e => {
  const file = e.dataTransfer.files[0];
  if (file) handleUpload(file);
});
dropzone.addEventListener("click", () => fileInput.click());
document.getElementById("browseLink").addEventListener("click", e => {
  e.stopPropagation();
  fileInput.click();
});
fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) handleUpload(fileInput.files[0]);
});

async function handleUpload(file) {
  const progressWrap = document.getElementById("uploadProgress");
  const progressBar = document.getElementById("progressBar");
  const errorBox = document.getElementById("uploadError");
  errorBox.classList.add("hidden");
  progressWrap.classList.remove("hidden");
  progressBar.style.width = "15%";

  const formData = new FormData();
  formData.append("file", file);

  try {
    progressBar.style.width = "55%";
    const data = await apiFetch("/api/upload", { method: "POST", body: formData });
    progressBar.style.width = "100%";

    state.datasetId = data.dataset_id;
    state.filename = data.filename;
    state.columns = data.column_names;

    setDatasetChip(`${data.filename} · ${data.rows}×${data.columns}`, true);

    document.getElementById("metaName").textContent = data.filename;
    document.getElementById("metaRows").textContent = data.rows.toLocaleString();
    document.getElementById("metaCols").textContent = data.columns;
    document.getElementById("metaSize").textContent = fmtBytes(data.size_bytes);
    document.getElementById("fileMeta").classList.remove("hidden");

    renderPreviewTable(data.preview, data.column_names);
    document.getElementById("previewWrap").classList.remove("hidden");

    document.getElementById("cleanEmpty").classList.add("hidden");
    document.getElementById("cleanForm").classList.remove("hidden");
    document.getElementById("dupCountLabel").textContent =
      `${data.summary.duplicates} duplicate row(s) detected.`;

    // Load a first pass of everything else so pages aren't empty
    await refreshEverything();

    setTimeout(() => progressWrap.classList.add("hidden"), 600);
  } catch (err) {
    progressWrap.classList.add("hidden");
    errorBox.textContent = err.message;
    errorBox.classList.remove("hidden");
  }
}

function renderPreviewTable(rows, columns) {
  const table = document.getElementById("previewTable");
  table.innerHTML = "";
  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  columns.forEach(c => {
    const th = document.createElement("th");
    th.textContent = c;
    headRow.appendChild(th);
  });
  thead.appendChild(headRow);
  const tbody = document.createElement("tbody");
  rows.forEach(r => {
    const tr = document.createElement("tr");
    columns.forEach(c => {
      const td = document.createElement("td");
      td.textContent = r[c] === null || r[c] === undefined ? "" : r[c];
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(thead);
  table.appendChild(tbody);
}

// ---------------------------------------------------------------- clean
document.querySelectorAll('input[name="missingStrategy"]').forEach(r =>
  r.addEventListener("change", () => {
    document.getElementById("fillOptions").style.display =
      document.querySelector('input[name="missingStrategy"]:checked').value === "fill" ? "flex" : "none";
  })
);
document.getElementById("fillOptions").style.display = "none";

document.getElementById("fillMethod").addEventListener("change", (e) => {
  document.getElementById("customValue").classList.toggle("hidden", e.target.value !== "custom");
});

document.getElementById("runCleanBtn").addEventListener("click", runClean);

async function runClean() {
  if (!state.datasetId) return;
  const missingStrategy = document.querySelector('input[name="missingStrategy"]:checked').value;
  const outlierMethod = document.querySelector('input[name="outlierMethod"]:checked').value;
  const normalize = document.querySelector('input[name="normalize"]:checked').value;

  const options = {
    remove_duplicates: document.getElementById("removeDuplicates").checked,
    missing: {
      strategy: missingStrategy,
      method: document.getElementById("fillMethod").value,
      custom_value: document.getElementById("customValue").value || null,
    },
    outliers: { method: outlierMethod },
    normalize,
  };

  const btn = document.getElementById("runCleanBtn");
  btn.disabled = true;
  btn.textContent = "Cleaning…";

  try {
    const result = await apiFetch("/api/clean", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dataset_id: state.datasetId, options }),
    });
    renderCompare(result.before, result.after);
    document.getElementById("compareWrap").classList.remove("hidden");
    await refreshEverything();
  } catch (err) {
    alert(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "Run cleaning";
  }
}

function renderCompare(before, after) {
  const rowsSpec = [
    ["Rows", "rows"],
    ["Columns", "columns"],
    ["Missing values", "missing_total"],
    ["Duplicate rows", "duplicates"],
    ["Outliers", "outliers_total"],
  ];
  const beforeList = document.getElementById("beforeList");
  const afterList = document.getElementById("afterList");
  beforeList.innerHTML = "";
  afterList.innerHTML = "";
  rowsSpec.forEach(([label, key]) => {
    beforeList.innerHTML += `<li><span>${label}</span><span>${before[key]}</span></li>`;
    afterList.innerHTML += `<li><span>${label}</span><span>${after[key]}</span></li>`;
  });
}

// ---------------------------------------------------------------- summary
function renderSummary(summary) {
  const grid = document.getElementById("statGrid");
  const cards = [
    ["📄", summary.rows, "Total rows"],
    ["📑", summary.columns, "Total columns"],
    ["❓", summary.missing_total, "Missing values"],
    ["🧬", summary.duplicates, "Duplicate rows"],
    ["📉", summary.outliers_total, "Outliers detected"],
    ["🔢", summary.numeric_columns.length, "Numeric columns"],
    ["🔤", summary.categorical_columns.length, "Categorical columns"],
  ];
  grid.innerHTML = cards.map(([icon, value, label]) => `
    <div class="stat-card">
      <div class="stat-icon">${icon}</div>
      <div class="stat-value">${value}</div>
      <div class="stat-label">${label}</div>
    </div>
  `).join("");
  grid.classList.remove("hidden");
  document.getElementById("summaryEmpty").classList.add("hidden");
}

// ---------------------------------------------------------------- visualize
let lastFigureDiv = null;

function populateAxisSelectors() {
  const xSel = document.getElementById("xAxis");
  const ySel = document.getElementById("yAxis");
  xSel.innerHTML = state.tableColumns.map(c => `<option value="${c}">${c}</option>`).join("");
  ySel.innerHTML = state.numericColumns.map(c => `<option value="${c}">${c}</option>`).join("");
}

document.getElementById("chartType").addEventListener("change", (e) => {
  const needsY = ["bar", "line", "scatter", "box"].includes(e.target.value);
  document.getElementById("yAxisWrap").style.display = needsY ? "flex" : "none";
});

document.getElementById("drawChartBtn").addEventListener("click", drawChart);

async function drawChart() {
  const type = document.getElementById("chartType").value;
  const x = document.getElementById("xAxis").value;
  const y = document.getElementById("yAxis").value;
  const area = document.getElementById("chartArea");
  area.classList.remove("hidden");

  if (type === "heatmap") {
    const corr = await apiFetch(`/api/correlation?dataset_id=${state.datasetId}`);
    if (corr.columns.length < 2) {
      area.innerHTML = "<p class='muted' style='padding:20px;'>Need at least two numeric columns for a correlation heatmap.</p>";
      return;
    }
    const trace = {
      type: "heatmap",
      z: corr.matrix,
      x: corr.columns,
      y: corr.columns,
      colorscale: [[0, "#EF4444"], [0.5, "#F8FAFC"], [1, "#4F46E5"]],
      zmin: -1, zmax: 1,
    };
    Plotly.newPlot(area, [trace], baseLayout("Correlation heatmap"), plotConfig());
    lastFigureDiv = area;
    return;
  }

  const rows = state.tableRows;
  if (!rows.length) return;

  let traces = [];
  let layout = baseLayout(`${type[0].toUpperCase() + type.slice(1)} chart`);

  if (type === "pie") {
    const counts = {};
    rows.forEach(r => {
      const key = r[x] === null || r[x] === undefined ? "N/A" : String(r[x]);
      counts[key] = (counts[key] || 0) + 1;
    });
    traces = [{ type: "pie", labels: Object.keys(counts), values: Object.values(counts), hole: 0.45 }];
  } else if (type === "histogram") {
    traces = [{ type: "histogram", x: rows.map(r => r[x]), marker: { color: "#4F46E5" } }];
  } else if (type === "bar") {
    const grouped = {};
    rows.forEach(r => {
      const key = r[x] === null || r[x] === undefined ? "N/A" : String(r[x]);
      const val = Number(r[y]) || 0;
      grouped[key] = (grouped[key] || 0) + val;
    });
    traces = [{ type: "bar", x: Object.keys(grouped), y: Object.values(grouped), marker: { color: "#7C3AED" } }];
  } else if (type === "line") {
    const sorted = [...rows].sort((a, b) => (a[x] > b[x] ? 1 : -1));
    traces = [{ type: "scatter", mode: "lines+markers", x: sorted.map(r => r[x]), y: sorted.map(r => r[y]), line: { color: "#4F46E5" } }];
  } else if (type === "scatter") {
    traces = [{ type: "scatter", mode: "markers", x: rows.map(r => r[x]), y: rows.map(r => r[y]), marker: { color: "#7C3AED", size: 7, opacity: 0.75 } }];
  } else if (type === "box") {
    traces = [{ type: "box", y: rows.map(r => r[y]), x: rows.map(r => r[x]), marker: { color: "#4F46E5" } }];
  }

  Plotly.newPlot(area, traces, layout, plotConfig());
  lastFigureDiv = area;
}

function baseLayout(title) {
  return {
    title: { text: title, font: { family: "Sora, sans-serif", size: 16 } },
    paper_bgcolor: "#fff",
    plot_bgcolor: "#fff",
    font: { family: "Inter, sans-serif", color: "#1B1E2B" },
    margin: { t: 50, l: 50, r: 20, b: 60 },
    autosize: true,
  };
}
function plotConfig() { return { responsive: true, displaylogo: false }; }

// ---------------------------------------------------------------- insights
function renderInsights(list) {
  const container = document.getElementById("insightList");
  document.getElementById("insightsEmpty").classList.add("hidden");
  container.innerHTML = list.map(text => `<div class="insight-item">${text}</div>`).join("");
}

// ---------------------------------------------------------------- table
document.getElementById("tableSearch").addEventListener("input", (e) => {
  state.searchTerm = e.target.value.toLowerCase();
  state.page = 1;
  renderFullTable();
});
document.getElementById("prevPage").addEventListener("click", () => {
  if (state.page > 1) { state.page--; renderFullTable(); }
});
document.getElementById("nextPage").addEventListener("click", () => {
  const maxPage = Math.max(1, Math.ceil(filteredRows().length / state.pageSize));
  if (state.page < maxPage) { state.page++; renderFullTable(); }
});

function filteredRows() {
  if (!state.searchTerm) return state.tableRows;
  return state.tableRows.filter(row =>
    Object.values(row).some(v => String(v ?? "").toLowerCase().includes(state.searchTerm))
  );
}

function renderColumnToggles() {
  const wrap = document.getElementById("colToggle");
  wrap.innerHTML = state.tableColumns.map(c => `
    <label><input type="checkbox" data-col="${c}" ${state.visibleColumns.has(c) ? "checked" : ""}> ${c}</label>
  `).join("");
  wrap.querySelectorAll("input").forEach(cb => {
    cb.addEventListener("change", () => {
      if (cb.checked) state.visibleColumns.add(cb.dataset.col);
      else state.visibleColumns.delete(cb.dataset.col);
      renderFullTable();
    });
  });
}

function renderFullTable() {
  let rows = filteredRows();
  if (state.sortCol) {
    rows = [...rows].sort((a, b) => {
      const va = a[state.sortCol], vb = b[state.sortCol];
      if (va === vb) return 0;
      if (va === null || va === undefined) return 1;
      if (vb === null || vb === undefined) return -1;
      return (va > vb ? 1 : -1) * state.sortDir;
    });
  }

  const total = rows.length;
  const maxPage = Math.max(1, Math.ceil(total / state.pageSize));
  state.page = Math.min(state.page, maxPage);
  const start = (state.page - 1) * state.pageSize;
  const pageRows = rows.slice(start, start + state.pageSize);
  const cols = state.tableColumns.filter(c => state.visibleColumns.has(c));

  const table = document.getElementById("fullTable");
  const thead = `<thead><tr>${cols.map(c => `<th data-col="${c}">${c}${state.sortCol === c ? (state.sortDir === 1 ? " ▲" : " ▼") : ""}</th>`).join("")}</tr></thead>`;
  const tbody = `<tbody>${pageRows.map(r => `<tr>${cols.map(c => `<td>${r[c] === null || r[c] === undefined ? "" : r[c]}</td>`).join("")}</tr>`).join("")}</tbody>`;
  table.innerHTML = thead + tbody;

  table.querySelectorAll("th").forEach(th => {
    th.addEventListener("click", () => {
      const col = th.dataset.col;
      if (state.sortCol === col) state.sortDir *= -1;
      else { state.sortCol = col; state.sortDir = 1; }
      renderFullTable();
    });
  });

  document.getElementById("pageLabel").textContent = `Page ${state.page} of ${maxPage} · ${total.toLocaleString()} rows`;
}

// ---------------------------------------------------------------- export
document.getElementById("exportCsv").addEventListener("click", () => {
  window.location.href = `${API_BASE}/api/export?dataset_id=${state.datasetId}&format=csv`;
});
document.getElementById("exportXlsx").addEventListener("click", () => {
  window.location.href = `${API_BASE}/api/export?dataset_id=${state.datasetId}&format=xlsx`;
});
document.getElementById("exportReport").addEventListener("click", () => {
  window.location.href = `${API_BASE}/api/report?dataset_id=${state.datasetId}`;
});
document.getElementById("exportChart").addEventListener("click", () => {
  if (!lastFigureDiv) { alert("Draw a chart on the Visualize page first."); return; }
  Plotly.downloadImage(lastFigureDiv, { format: "png", filename: "chart" });
});

// ---------------------------------------------------------------- refresh
async function refreshEverything() {
  if (!state.datasetId) return;

  const dataResp = await apiFetch(`/api/data?dataset_id=${state.datasetId}`);
  state.tableColumns = dataResp.columns;
  state.numericColumns = dataResp.numeric_columns;
  state.tableRows = dataResp.rows;
  state.visibleColumns = new Set(dataResp.columns);

  populateAxisSelectors();
  document.getElementById("vizEmpty").classList.add("hidden");
  document.getElementById("vizControls").classList.remove("hidden");

  document.getElementById("tableEmpty").classList.add("hidden");
  document.getElementById("tableControls").classList.remove("hidden");
  document.getElementById("fullTableWrap").classList.remove("hidden");
  document.getElementById("pagination").classList.remove("hidden");
  renderColumnToggles();
  state.page = 1;
  renderFullTable();

  try {
    const insightsResp = await apiFetch(`/api/insights?dataset_id=${state.datasetId}`);
    renderInsights(insightsResp.insights);
    document.getElementById("insightsEmpty").classList.add("hidden");
  } catch { /* not fatal */ }

  try {
    const summaryResp = await apiFetch(`/api/summary?dataset_id=${state.datasetId}`);
    renderSummary(summaryResp);
  } catch { /* not fatal */ }

  document.getElementById("exportEmpty").classList.add("hidden");
  document.getElementById("exportGrid").classList.remove("hidden");
}
